export class Product {
    price!: Number;
    rating!: Number;
    }
    