import { WinterOutfit } from './WinterOutfit';

export class Coat extends WinterOutfit {
}
