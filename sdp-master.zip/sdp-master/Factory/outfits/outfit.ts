import { Product } from '../Product';

export class outfit extends Product {
  colour!: string;
  size!: string;
}