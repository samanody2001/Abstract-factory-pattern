
import { outfit } from './outfit';

export class SummerOutfit extends outfit {
}
