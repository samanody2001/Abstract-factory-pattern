import { SummerOutfit } from './SummerOutfit';

export class Short extends SummerOutfit {

}
