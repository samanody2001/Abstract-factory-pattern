
import { outfit } from "./outfit";

export class WinterOutfit extends outfit{
  }
  