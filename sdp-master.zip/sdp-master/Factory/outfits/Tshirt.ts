import { SummerOutfit } from './SummerOutfit';

export class Tshirt extends SummerOutfit {
}
