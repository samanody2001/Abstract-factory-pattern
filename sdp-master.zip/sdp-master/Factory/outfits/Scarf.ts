import { WinterOutfit } from './WinterOutfit';

export class Scarf extends WinterOutfit {
}