import {  WinterOutfit } from './WinterOutfit';

export class Sweater extends WinterOutfit {

}