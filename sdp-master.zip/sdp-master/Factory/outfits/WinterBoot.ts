import { WinterOutfit } from './WinterOutfit';

export class WinterBoot extends WinterOutfit {
}
