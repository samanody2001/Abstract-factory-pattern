import { SummerOutfit } from './SummerOutfit';

export class Slipper extends SummerOutfit {
}
