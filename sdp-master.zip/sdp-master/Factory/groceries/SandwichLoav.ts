import { Grocerie } from "./Grocerie";

export class SandwichLoav extends Grocerie {
    }