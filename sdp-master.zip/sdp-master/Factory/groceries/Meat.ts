import { Grocerie } from "./Grocerie";

export class Meat extends Grocerie {
  }