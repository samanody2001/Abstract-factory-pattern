import { Grocerie } from "./Grocerie";



export class Cheese extends Grocerie {
}