import { Grocerie } from "./Grocerie";

export class SpaghetiSauce extends Grocerie {
    }