import { Grocerie } from './Grocerie';

export class Milk extends Grocerie {}
