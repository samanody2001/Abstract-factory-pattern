import { Grocerie } from "./Grocerie";

export class Icecream extends Grocerie {
    }
