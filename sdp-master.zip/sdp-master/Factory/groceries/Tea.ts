import { Grocerie } from "./Grocerie";

export class Tea extends Grocerie {
    }