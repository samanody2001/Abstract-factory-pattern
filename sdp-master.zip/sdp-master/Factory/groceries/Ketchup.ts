import { Grocerie } from "./Grocerie";

export class Ketchup extends Grocerie {
    }