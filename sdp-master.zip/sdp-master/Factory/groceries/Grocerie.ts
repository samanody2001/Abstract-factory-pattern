import { Product } from '../Product';

export class Grocerie extends Product {
}
