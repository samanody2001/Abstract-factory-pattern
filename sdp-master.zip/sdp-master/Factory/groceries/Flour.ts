import { Grocerie } from "./Grocerie";

export class Flour extends Grocerie {
  }