import { Grocerie } from "./Grocerie";



export class Bagel extends Grocerie {
}
