import { Grocerie } from "./Grocerie";

export class Waffle extends Grocerie {
    }