import { Grocerie } from "./Grocerie";

export class Juice extends Grocerie {
    }