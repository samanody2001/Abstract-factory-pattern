import { Grocerie } from "./Grocerie";



export class DinnerRoll extends Grocerie {
}