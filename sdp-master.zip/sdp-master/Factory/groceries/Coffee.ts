import { Grocerie } from "./Grocerie";



export class Coffee extends Grocerie {
}