import { Grocerie } from "./Grocerie";

export class Pasta extends Grocerie {
    }