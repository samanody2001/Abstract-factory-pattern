import { Grocerie } from "./Grocerie";

export class Tortilla extends Grocerie {
    }