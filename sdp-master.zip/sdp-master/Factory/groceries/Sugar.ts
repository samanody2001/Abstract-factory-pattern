import { Grocerie } from "./Grocerie";

export class Sugar extends Grocerie {
    }