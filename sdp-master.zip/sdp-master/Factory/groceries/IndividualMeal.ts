import { Grocerie } from "./Grocerie";

export class IndividualMeal extends Grocerie {
    }