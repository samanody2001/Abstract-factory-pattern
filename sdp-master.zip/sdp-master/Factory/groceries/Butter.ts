import { Grocerie } from "./Grocerie";



export class Butter extends Grocerie {
}