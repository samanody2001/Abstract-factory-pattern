import { Grocerie } from "./Grocerie";

export class Soda extends Grocerie {
    }