import { Grocerie } from "./Grocerie";

export class Yogurt extends Grocerie {
    }