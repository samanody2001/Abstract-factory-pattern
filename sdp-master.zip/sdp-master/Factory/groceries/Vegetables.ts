import { Grocerie } from "./Grocerie";

export class Vegetables extends Grocerie {
    }