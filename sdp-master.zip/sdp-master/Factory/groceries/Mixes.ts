import { Grocerie } from "./Grocerie";

export class Mixes extends Grocerie {
    }