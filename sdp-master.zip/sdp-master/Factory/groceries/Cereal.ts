import { Grocerie } from "./Grocerie";



export class Cereal extends Grocerie {
}