import { Grocerie } from "./Grocerie";



export class Eggs extends Grocerie {
}
