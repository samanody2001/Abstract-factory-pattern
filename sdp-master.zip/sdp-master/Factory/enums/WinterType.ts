export enum WinterType {
    COAT = 1,
    SWEATER=2,
    WINTERBOOT=3,
    SCARF=4,
  }