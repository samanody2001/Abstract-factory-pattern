export enum HandtoolType {
    HAMMER=1,
    HANDSAW=2,
    PLIER=3,
    SCREWDRIVER=4,
  }
  