export enum Colour {
    BLACK=1,
    WHITE=2,
  }