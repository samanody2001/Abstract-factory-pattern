export enum PowertoolType {
    DRILL=1,
    IMPACTDRIVER=2,
    IMPACTWRENCH=3,
    SANDER=4,
    SAW=5,
  }