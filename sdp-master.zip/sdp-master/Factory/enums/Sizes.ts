export enum Size {
    SMALL=1,
    MEDIUM=2,
    LARGE=3,
  }