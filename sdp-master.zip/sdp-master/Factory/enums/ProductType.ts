export enum ProductType {
    GROCERIE=1,
    HANDTOOL=2,
    POWERTOOL=3,
    SUMMEROUTFIT=4,
    WINTEROUTFIT=5,
      }