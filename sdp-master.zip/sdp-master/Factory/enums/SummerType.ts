export enum SummerType {
    TSHIRT=1,
    SLIPPER=2,
    SHORT=3,
  }
  