import { Handtool } from "./Handtool";


export class Plier extends Handtool {
}