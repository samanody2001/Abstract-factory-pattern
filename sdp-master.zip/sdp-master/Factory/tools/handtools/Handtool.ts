import { Product } from "../../Product";

export class Handtool extends Product{
    }
    