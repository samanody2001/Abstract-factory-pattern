import { Handtool } from "./Handtool";


export class HandSaw extends Handtool {
}