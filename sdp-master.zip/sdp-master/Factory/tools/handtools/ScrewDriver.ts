import { Handtool } from './Handtool';

export class ScrewDriver extends Handtool {
}
