import { Handtool } from "./Handtool";


export class Hammer extends Handtool {
}
