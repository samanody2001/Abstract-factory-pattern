import { Powertool } from './Powertool';

export class Saw extends Powertool {}
