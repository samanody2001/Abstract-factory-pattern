import { Powertool } from "./Powertool";



export class Sander extends Powertool {
}