import { Product } from "../../Product";

export class Powertool extends Product {
    }
    