import { Powertool } from "./Powertool";



export class Drill extends Powertool {
}