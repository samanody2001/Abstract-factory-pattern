import { Powertool } from "./Powertool";



export class ImpactWrench extends Powertool {
}