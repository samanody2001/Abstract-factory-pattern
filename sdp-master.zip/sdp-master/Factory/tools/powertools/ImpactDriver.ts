import { Powertool } from "./Powertool";



export class ImpactDriver extends Powertool {
}