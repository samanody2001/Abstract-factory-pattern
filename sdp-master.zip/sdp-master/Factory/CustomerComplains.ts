export let arr_of_complains = [
    "Customer one first complain"
];
