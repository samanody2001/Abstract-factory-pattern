// import { GrocerieFactory } from './GrocerieFactory';
// import { HandtoolFactory } from './HandtoolFactory';
// import { PowertoolFactory } from './PowertoolFactory';
// import { SummerOutfitFactory } from './SummerOutfitFactory';
// import { WinterOutfitFactory } from './WinterOutfitFactory';
// import { FactoryType } from '../enums/FactoryType';


// export class FactoryOrchestrator {
// createFactory(factoryType: FactoryType) {
//     return {
//       [FactoryType.GROCERIE]: new GrocerieFactory(),
//       [FactoryType.HANDTOOL]: new HandtoolFactory(),
//       [FactoryType.POWERTOOL]: new PowertoolFactory(),
//     //   [FactoryType.SUMMEROUTFIT]: new SummerOutfitFactory(),
//     //   [FactoryType.WINTEROUTFIT]: new WinterOutfitFactory(),
//     }[factoryType];
//   }
// }
